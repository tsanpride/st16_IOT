<?php
session_start();
session_destroy();
header("location:https://t.me/lordjalalbot")
?>