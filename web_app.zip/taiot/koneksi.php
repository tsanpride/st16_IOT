<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'doortoken';
 
/* Attempt to connect to MySQL database with oop */
$conn = mysqli_connect($host,$user, $pass);
mysqli_select_db($conn, $db);

?>